#!/usr/bin/env python3
import sys
r=0
import json
# Opening JSON file
f = open('embedding-sample.json')
data = json.load(f)
for line in sys.stdin:
    r=r+1
    k=int(line.split("[")[0].replace(" ", ""))
    ll=list(map(lambda x: int(x.replace(" ", "")), line.split("[")[1][:-2].split(",")))
    l=len(ll)
    for i in ll:
        # print([k,i,float(1/l)])
        p=data[str(k)]
        q=data[str(i)]
        m=[pi*qi for (pi,qi) in zip(p,q)]
        # print(p,q)
        p_mod=0
        q_mod=0
        for o in range(len(p)):
            p_mod+=p[o]**2
            q_mod+=q[o]**2
        p_mod=p_mod**(0.5)
        q_mod=q_mod**(0.5)
        print(i,k,round(sum(m)/(p_mod*q_mod), 2)*float(1/l))#m/((p_mod**(0.5)(q_mod**(0.5))))