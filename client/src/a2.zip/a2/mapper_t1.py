#!/usr/bin/env python3
import sys
c=0
for line in sys.stdin:
    if(line.split("\t")[1][-1]!='\n'):
        print(line.split("\t")[0],line.split("\t")[1])
    else:
        print(line.split("\t")[0],line.split("\t")[1][:-1])