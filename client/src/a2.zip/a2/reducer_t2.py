#!/usr/bin/env python3
import sys
first=1
c=0
sum=0
f = open(sys.argv[1], "w")
for line in sys.stdin:
    # print(sum)
    if(first):
        first=0
        c=int(line.split(" ")[0])
        sum=float(line.split(" ")[2][:-1])
        continue
    if(c==int(line.split(" ")[0])):
        sum+=float(line.split(" ")[2][:-1])
    else:
        f.write(str(c)+","+str(round(0.15+(0.85*sum),2))+"\n")
        c=int(line.split(" ")[0])
        sum=float(line.split(" ")[2][:-1])

f.write(str(c)+","+str(round(0.15+(0.85*sum),2))+"\n")
f.close()
    