#!/usr/bin/env python3
import sys
l=[]
c=1
x=1
f = open(sys.argv[1], "w")
for line in sys.stdin:
    p=line.split(" ")
    if(x==1):
        x=0
        c=p[0]
        l.append(int(p[1]))
        continue
    if(c==p[0]):
        l.append(int(p[1]))
    else:
        f.write(str(c)+",1\n")
        print(str(c)+" "+str(l))
        c=p[0]
        l=[]
        l.append(int(p[1]))
print(str(c)+" "+str(l))
f.write(str(c)+",1\n")
f.close()
